<template>
    <div class="content-wrapper">
        Partner List
    </div>
</template>

<script>
export default {
    name : "PartnerList"
}
</script>

<style>

</style>